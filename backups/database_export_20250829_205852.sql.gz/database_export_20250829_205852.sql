--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS fince_project_prod;
--
-- Name: fince_project_prod; Type: DATABASE; Schema: -; Owner: fince_app_project
--

CREATE DATABASE fince_project_prod WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'zh_CN.UTF-8';


ALTER DATABASE fince_project_prod OWNER TO fince_app_project;

\connect fince_project_prod

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    parent_id uuid,
    icon character varying(50),
    color character varying(7),
    is_system character varying(1) DEFAULT '0'::character varying,
    is_active character varying(1) DEFAULT '1'::character varying,
    sort_order character varying(10) DEFAULT '0'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    project_code character varying(50),
    description text,
    project_type character varying(50) DEFAULT 'other'::character varying,
    category character varying(100),
    tags jsonb DEFAULT '[]'::jsonb,
    status character varying(20) DEFAULT 'planning'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    progress integer DEFAULT 0,
    health_status character varying(20) DEFAULT 'healthy'::character varying,
    start_date date,
    end_date date,
    actual_start_date date,
    actual_end_date date,
    estimated_duration integer,
    actual_duration integer,
    budget numeric(15,2),
    actual_cost numeric(15,2) DEFAULT 0,
    estimated_cost numeric(15,2),
    cost_variance numeric(15,2),
    budget_utilization numeric(5,2),
    manager_name character varying(100),
    manager_id uuid,
    team_size integer DEFAULT 1,
    assigned_users jsonb DEFAULT '[]'::jsonb,
    location jsonb DEFAULT '{}'::jsonb,
    address character varying(500),
    coordinates jsonb,
    client_info jsonb DEFAULT '{}'::jsonb,
    contract_info jsonb DEFAULT '{}'::jsonb,
    contract_number character varying(100),
    contract_value numeric(15,2),
    payment_terms jsonb,
    technical_specs jsonb,
    requirements jsonb,
    deliverables jsonb,
    quality_standards jsonb,
    risk_level character varying(20) DEFAULT 'low'::character varying,
    risk_factors jsonb,
    mitigation_plans jsonb,
    budget_change_reason character varying(200),
    contract_change_reason character varying(200),
    change_description text,
    documents jsonb DEFAULT '[]'::jsonb,
    attachments jsonb DEFAULT '[]'::jsonb,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    approval_history jsonb,
    workflow_stage character varying(50),
    last_review_date date,
    next_review_date date,
    review_cycle character varying(20),
    reporting_frequency character varying(20),
    is_active boolean DEFAULT true,
    is_template boolean DEFAULT false,
    created_by uuid,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(50),
    contact_person character varying(100),
    phone character varying(20),
    email character varying(100),
    address text,
    business_scope text,
    qualification text,
    credit_rating character varying(10),
    payment_terms character varying(200),
    is_active character varying(1) DEFAULT '1'::character varying,
    notes text,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    domain character varying(50),
    plan_type character varying(20) DEFAULT 'trial'::character varying,
    settings jsonb DEFAULT '{}'::jsonb,
    subscription_end date,
    storage_used bigint DEFAULT 0,
    storage_limit bigint DEFAULT '5368709120'::bigint,
    api_calls_used integer DEFAULT 0,
    api_calls_limit integer DEFAULT 1000,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    project_id uuid,
    supplier_id uuid,
    category_id uuid,
    transaction_date date NOT NULL,
    type character varying(10) NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency character varying(10) DEFAULT 'CNY'::character varying,
    exchange_rate numeric(10,6) DEFAULT 1.000000,
    description text,
    notes text,
    tags jsonb,
    payment_method character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    attachment_url character varying(500),
    reference_number character varying(100),
    approved_by character varying(100),
    approved_at timestamp without time zone,
    created_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    permissions jsonb DEFAULT '[]'::jsonb,
    profile jsonb DEFAULT '{}'::jsonb,
    last_login timestamp without time zone,
    login_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    two_factor_enabled boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, tenant_id, name, parent_id, icon, color, is_system, is_active, sort_order, created_at, updated_at) FROM stdin;
235c1277-1d05-43b1-98a3-e14ed87aabdc	a0d9c172-15e6-4642-9304-ee8df18ee158	测试分类	\N	\N	\N	1	1	0	2025-08-29 20:56:22.154838	2025-08-29 20:56:22.154838
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, tenant_id, name, project_code, description, project_type, category, tags, status, priority, progress, health_status, start_date, end_date, actual_start_date, actual_end_date, estimated_duration, actual_duration, budget, actual_cost, estimated_cost, cost_variance, budget_utilization, manager_name, manager_id, team_size, assigned_users, location, address, coordinates, client_info, contract_info, contract_number, contract_value, payment_terms, technical_specs, requirements, deliverables, quality_standards, risk_level, risk_factors, mitigation_plans, budget_change_reason, contract_change_reason, change_description, documents, attachments, approval_status, approval_history, workflow_stage, last_review_date, next_review_date, review_cycle, reporting_frequency, is_active, is_template, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (id, tenant_id, name, code, contact_person, phone, email, address, business_scope, qualification, credit_rating, payment_terms, is_active, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, domain, plan_type, settings, subscription_end, storage_used, storage_limit, api_calls_used, api_calls_limit, status, created_at, updated_at) FROM stdin;
a0d9c172-15e6-4642-9304-ee8df18ee158	测试租户	test.local	trial	{}	\N	0	5368709120	0	1000	active	2025-08-29 20:56:22.154838	2025-08-29 20:56:22.154838
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, tenant_id, project_id, supplier_id, category_id, transaction_date, type, amount, currency, exchange_rate, description, notes, tags, payment_method, status, attachment_url, reference_number, approved_by, approved_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, tenant_id, username, email, password_hash, role, permissions, profile, last_login, login_count, is_active, email_verified, two_factor_enabled, created_at, updated_at) FROM stdin;
c750d4d3-0327-4051-9af2-aa50e019d747	a0d9c172-15e6-4642-9304-ee8df18ee158	admin	admin@test.local	test_hash	admin	[]	{}	\N	0	t	f	f	2025-08-29 20:56:22.154838	2025-08-29 20:56:22.154838
\.


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_project_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_project_code_key UNIQUE (project_code);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_domain_key UNIQUE (domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: categories categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: projects projects_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: projects projects_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: projects projects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: projects projects_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: suppliers suppliers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: suppliers suppliers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: transactions transactions_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: transactions transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

