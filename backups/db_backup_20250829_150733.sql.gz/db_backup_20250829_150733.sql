--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_operation_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_operation_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    admin_user_id uuid NOT NULL,
    operation_type character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid,
    operation_details json,
    ip_address inet,
    user_agent text,
    tenant_id uuid,
    operation_result text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_operation_logs OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    parent_id uuid,
    icon character varying(50),
    color character varying(7),
    is_system character varying(1) DEFAULT '0'::character varying,
    is_active character varying(1) DEFAULT '1'::character varying,
    sort_order character varying(10) DEFAULT '0'::character varying,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: health_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_checks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    service_name character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    response_time integer,
    error_details text,
    check_details json,
    service_version character varying(50),
    last_success timestamp without time zone,
    failure_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.health_checks OWNER TO postgres;

--
-- Name: monitoring_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitoring_data (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    service_name character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    response_time integer,
    error_message text,
    extra_data json,
    alert_threshold numeric(15,4),
    alert_enabled boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.monitoring_data OWNER TO postgres;

--
-- Name: project_change_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_change_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    project_id uuid NOT NULL,
    change_type character varying(50) NOT NULL,
    field_name character varying(100),
    old_value text,
    new_value text,
    change_description text,
    change_reason text,
    changed_by uuid,
    ip_address inet,
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.project_change_logs OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    project_code character varying(50),
    description text,
    project_type character varying(50) DEFAULT 'construction'::character varying,
    category character varying(100),
    tags jsonb DEFAULT '[]'::jsonb,
    status character varying(20) DEFAULT 'planning'::character varying,
    priority character varying(20) DEFAULT 'medium'::character varying,
    progress integer DEFAULT 0,
    health_status character varying(20) DEFAULT 'healthy'::character varying,
    start_date date,
    end_date date,
    actual_start_date date,
    actual_end_date date,
    estimated_duration integer,
    actual_duration integer,
    budget numeric(15,2),
    actual_cost numeric(15,2) DEFAULT 0,
    estimated_cost numeric(15,2),
    cost_variance numeric(15,2),
    budget_utilization numeric(5,2),
    manager_name character varying(100),
    manager_id uuid,
    team_size integer DEFAULT 1,
    assigned_users jsonb DEFAULT '[]'::jsonb,
    location jsonb DEFAULT '{}'::jsonb,
    address character varying(500),
    coordinates jsonb,
    client_info jsonb DEFAULT '{}'::jsonb,
    contract_info jsonb DEFAULT '{}'::jsonb,
    contract_number character varying(100),
    contract_value numeric(15,2),
    payment_terms jsonb,
    technical_specs jsonb,
    requirements jsonb,
    deliverables jsonb,
    quality_standards jsonb,
    risk_level character varying(20) DEFAULT 'low'::character varying,
    risk_factors jsonb,
    mitigation_plans jsonb,
    budget_change_reason character varying(200),
    contract_change_reason character varying(200),
    change_description text,
    documents jsonb DEFAULT '[]'::jsonb,
    attachments jsonb DEFAULT '[]'::jsonb,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    approval_history jsonb,
    workflow_stage character varying(50) DEFAULT 'draft'::character varying,
    last_review_date date,
    next_review_date date,
    review_cycle character varying(20),
    reporting_frequency character varying(20),
    created_by uuid,
    updated_by uuid,
    is_active boolean DEFAULT true,
    is_template boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(50),
    contact_person character varying(100),
    phone character varying(20),
    email character varying(100),
    address text,
    business_scope text,
    qualification text,
    credit_rating character varying(10),
    payment_terms character varying(200),
    is_active character varying(1) DEFAULT '1'::character varying,
    notes text,
    tax_id character varying(50),
    bank_account character varying(100),
    rating integer DEFAULT 0,
    website character varying(200),
    qualification_certificates jsonb DEFAULT '[]'::jsonb,
    performance_history jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: system_statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_statistics (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    stat_date date NOT NULL,
    stat_type character varying(50) NOT NULL,
    stat_data json NOT NULL,
    alert_threshold numeric(15,4),
    alert_enabled boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_statistics OWNER TO postgres;

--
-- Name: tenant_activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenant_activity (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    activity_date date NOT NULL,
    login_count integer DEFAULT 0,
    project_operations integer DEFAULT 0,
    transaction_operations integer DEFAULT 0,
    supplier_operations integer DEFAULT 0,
    last_activity_at timestamp without time zone,
    activity_score integer DEFAULT 0,
    session_id character varying(100),
    duration integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_activity OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    domain character varying(50),
    plan_type character varying(20) DEFAULT 'trial'::character varying,
    settings jsonb DEFAULT '{}'::jsonb,
    subscription_end date,
    storage_used bigint DEFAULT 0,
    storage_limit bigint DEFAULT '5368709120'::bigint,
    api_calls_used integer DEFAULT 0,
    api_calls_limit integer DEFAULT 1000,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    project_id uuid,
    supplier_id uuid,
    category_id uuid,
    transaction_date date NOT NULL,
    type character varying(10) NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency character varying(10) DEFAULT 'CNY'::character varying,
    exchange_rate numeric(10,6) DEFAULT 1.000000,
    description text,
    notes text,
    tags jsonb,
    payment_method character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    attachment_url character varying(500),
    reference_number character varying(100),
    approved_by character varying(100),
    approved_at timestamp without time zone,
    created_by uuid,
    invoice_number character varying(100),
    due_date date,
    attachments jsonb DEFAULT '[]'::jsonb,
    tax_amount numeric(15,2) DEFAULT 0,
    discount_amount numeric(15,2) DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    profile jsonb DEFAULT '{}'::jsonb,
    last_login timestamp without time zone,
    login_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    two_factor_enabled boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: admin_operation_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_operation_logs (id, admin_user_id, operation_type, target_type, target_id, operation_details, ip_address, user_agent, tenant_id, operation_result, created_at, updated_at) FROM stdin;
51fb4c58-f096-4842-b835-46f8774e3072	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	439096fb-e9c1-4137-b9a3-66d4f5158653	{"old_status": "active", "new_status": "disabled", "reason": "\\u6d4b\\u8bd5\\u7981\\u7528", "tenant_name": "\\u76d1\\u63a7\\u7cfb\\u7edf"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:22:42.500926	2025-08-28 07:22:42.500926
118f3c06-8417-43f1-b452-84936318b0ab	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "active", "new_status": "disabled", "reason": "\\u6d4b\\u8bd5\\u7981\\u7528\\u529f\\u80fd", "tenant_name": "888"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:26:37.62763	2025-08-28 07:26:37.62763
5779f9a9-3b12-407e-a17b-242a6c48b670	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "disabled", "new_status": "active", "reason": "\\u6d4b\\u8bd5\\u542f\\u7528\\u529f\\u80fd", "tenant_name": "888"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:26:38.711834	2025-08-28 07:26:38.711834
5347a5e1-06e8-4a45-a892-27c194b507ea	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "active", "new_status": "disabled", "reason": "\\u6d4b\\u8bd5\\u7981\\u7528\\u529f\\u80fd", "tenant_name": "888"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:30:15.755228	2025-08-28 07:30:15.755228
c309e85c-e6ba-4cdf-95ba-586bee892f66	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "disabled", "new_status": "active", "reason": "\\u6d4b\\u8bd5\\u542f\\u7528\\u529f\\u80fd", "tenant_name": "888"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:30:16.825764	2025-08-28 07:30:16.825764
6c63ffb8-d4dc-449b-b0d5-dc6455e2e1fe	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "active", "new_status": "disabled", "reason": "\\u6d4b\\u8bd5\\u7981\\u7528\\u529f\\u80fd", "tenant_name": "888"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:37:20.024281	2025-08-28 07:37:20.024281
c63049ad-26ba-4609-ae80-7a1f813d7c59	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "disabled", "new_status": "active", "reason": "\\u6d4b\\u8bd5\\u542f\\u7528\\u529f\\u80fd", "tenant_name": "888"}	127.0.0.1	python-requests/2.32.5	\N	\N	2025-08-28 07:37:21.146412	2025-08-28 07:37:21.146412
9707bdb1-401d-4c7d-a1ca-643babac8d9e	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "active", "new_status": "disabled", "reason": "", "tenant_name": "888"}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 07:47:57.746678	2025-08-28 07:47:57.746678
6de02345-e626-4c61-8881-8cecdec34f84	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"old_status": "disabled", "new_status": "active", "reason": "", "tenant_name": "888"}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 07:48:51.359173	2025-08-28 07:48:51.359173
16f2cb84-df30-4871-85e8-7c4aaae1dc99	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 09:59:07.613606	2025-08-28 09:59:07.613606
1f19ebf2-0e40-41f2-a2aa-fada319ccc1e	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 09:59:32.295989	2025-08-28 09:59:32.295989
1ff95234-28ab-4330-97ea-b76a915331be	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	reset_tenant_password	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"tenant_name": "888", "password_reset": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 09:59:47.466212	2025-08-28 09:59:47.466212
1986dfec-efed-4a10-85a7-b957da98ec70	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 10:48:21.947109	2025-08-28 10:48:21.947109
0189b448-e355-4b93-a0f4-c29d1273a43e	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 10:48:36.026797	2025-08-28 10:48:36.026797
b5e5a7e2-b1e8-4315-b585-29910b7a15f1	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": false, "new_status": true, "reason": "\\u6d4b\\u8bd5\\u542f\\u7528\\u7528\\u6237"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:49:19.316356	2025-08-28 10:49:19.316356
e1d47b6b-77ed-4ab3-8a80-ba289c03d02a	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_role	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_role": "super_admin", "new_role": "super_admin", "reason": "\\u6d4b\\u8bd5\\u6062\\u590d\\u89d2\\u8272"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:49:19.401931	2025-08-28 10:49:19.401931
275345fa-143d-427b-b00b-77e832816d7c	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 10:49:52.961488	2025-08-28 10:49:52.961488
cac829ed-4ecd-45d9-a659-0a08d48bd3c7	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 10:49:56.512935	2025-08-28 10:49:56.512935
f1862cdd-ce90-4ebd-9854-71e67282fb6c	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 10:50:25.667143	2025-08-28 10:50:25.667143
84732eb0-0f33-4fc4-9e0d-d7c61a47565b	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 10:50:36.018616	2025-08-28 10:50:36.018616
4ae730cb-6749-49dd-b6ce-662284625e23	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": false, "new_status": true, "reason": "\\u6d4b\\u8bd5\\u542f\\u7528\\u8d26\\u53f7"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:53:36.608961	2025-08-28 10:53:36.608961
2919675e-42a3-459c-aec8-1b0fd5b34ee8	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": true, "new_status": false, "reason": "\\u6d4b\\u8bd5\\u7981\\u7528\\u8d26\\u53f7"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:58:50.883326	2025-08-28 10:58:50.883326
6c287ee1-e61c-4437-922a-db8c9fceb38f	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": false, "new_status": true, "reason": "\\u6d4b\\u8bd5\\u91cd\\u65b0\\u542f\\u7528\\u8d26\\u53f7"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:59:02.588598	2025-08-28 10:59:02.588598
3ce4801f-601f-49ee-8156-461ecf6c459e	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": true, "new_status": false, "reason": "\\u6d4b\\u8bd5HTTPS\\u8bbf\\u95ee\\u65f6\\u7684\\u7981\\u7528\\u72b6\\u6001"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:59:30.77354	2025-08-28 10:59:30.77354
ca94861a-2efb-41e6-9d61-75629e01ddb9	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": false, "new_status": true, "reason": "\\u6d4b\\u8bd5HTTPS\\u8bbf\\u95ee\\u65f6\\u7684\\u542f\\u7528\\u72b6\\u6001"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 10:59:31.885912	2025-08-28 10:59:31.885912
effb3d87-4e8f-4686-bd01-ca5654fdc374	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:00:07.646272	2025-08-28 11:00:07.646272
aed53f63-ebdd-46ba-a73e-d73466e84645	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:00:26.36636	2025-08-28 11:00:26.36636
d44d4b30-d9a5-49f5-8121-9d371be80413	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_user_status	user	9df1686c-dc32-4777-8405-349524d81ff5	{"tenant_id": "b7685340-0e7b-4f33-a31f-4f157b810648", "tenant_name": "999", "user_email": "999@999.com", "old_status": false, "new_status": true, "reason": "\\u91cd\\u65b0\\u542f\\u7528\\u8d26\\u53f7"}	127.0.0.1	python-requests/2.31.0	\N	\N	2025-08-28 11:01:36.858124	2025-08-28 11:01:36.858124
032c88bb-18a7-456f-a1b5-c5b685f98163	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"tenant_name": "888", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:07:06.625777	2025-08-28 11:07:06.625777
b397a123-40e9-436e-a61e-ab26aeacda00	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	{"tenant_name": "888", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:07:11.581587	2025-08-28 11:07:11.581587
8f09aba4-0da4-443e-8173-f46a2fb7223d	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "test", "users_affected": true}	192.168.4.130	curl/8.5.0	\N	\N	2025-08-28 11:08:15.209942	2025-08-28 11:08:15.209942
50c9b230-c03f-44b8-9091-89c4195d3580	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "test", "users_affected": false}	192.168.4.130	curl/8.5.0	\N	\N	2025-08-28 11:08:19.569951	2025-08-28 11:08:19.569951
d050d264-5b8d-4bbe-806c-c8d697a46756	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "\\u6d4b\\u8bd5\\u7981\\u7528\\u529f\\u80fd", "users_affected": true}	192.168.4.130	python-requests/2.31.0	\N	\N	2025-08-28 11:09:16.013044	2025-08-28 11:09:16.013044
933c61c9-3b07-4ef9-82ee-4bbb11d7ae3d	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "\\u6d4b\\u8bd5\\u542f\\u7528\\u529f\\u80fd", "users_affected": false}	192.168.4.130	python-requests/2.31.0	\N	\N	2025-08-28 11:09:17.175566	2025-08-28 11:09:17.175566
5a5433df-89bb-4f4a-a6f8-997387c76b70	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:11:00.098902	2025-08-28 11:11:00.098902
124c2007-28e3-4d7c-be69-e466973e5898	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:11:07.268442	2025-08-28 11:11:07.268442
0158b674-6c25-48fb-8e8a-0b97ef630f3d	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:11:44.020858	2025-08-28 11:11:44.020858
6fd3d64a-6748-444e-9197-f02f2c2cd32a	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:13:39.165861	2025-08-28 11:13:39.165861
58910000-6f31-45d2-8239-8ea922aa5885	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "\\u6d4b\\u8bd5\\u64cd\\u4f5c", "users_affected": true}	192.168.4.130	python-requests/2.31.0	\N	\N	2025-08-28 11:16:07.768426	2025-08-28 11:16:07.768426
022b6ed0-249f-4877-b72f-84ab11b32d60	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "\\u6d4b\\u8bd5\\u91cd\\u65b0\\u542f\\u7528", "users_affected": false}	192.168.4.130	python-requests/2.31.0	\N	\N	2025-08-28 11:16:09.946877	2025-08-28 11:16:09.946877
beb4a750-c755-4d79-bbe8-b1d30179abe3	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:18:09.82514	2025-08-28 11:18:09.82514
c7d86707-b08c-4ef3-ad70-28a7ccbb6a3b	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:18:21.29643	2025-08-28 11:18:21.29643
9ea19587-9220-4105-9913-fb3d68470d07	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "11111", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:19:29.031177	2025-08-28 11:19:29.031177
5c729674-1cd2-423e-a037-1238d669abbf	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:19:44.431869	2025-08-28 11:19:44.431869
e0c0ebb8-c5a3-4f8c-bc04-cc52fc89a6c6	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:20:21.021748	2025-08-28 11:20:21.021748
bd654891-f2d1-414c-9eb0-e6a7f4390f56	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:23:12.15187	2025-08-28 11:23:12.15187
df87a477-95eb-407f-aea1-aac7df9e88b9	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:27:19.481092	2025-08-28 11:27:19.481092
2960c5c2-17eb-4130-a68f-69360dfccecb	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:28:01.974113	2025-08-28 11:28:01.974113
89c39274-bb6b-4fc2-b685-ad43fcd6d54e	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.130	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	\N	\N	2025-08-28 11:30:34.744912	2025-08-28 11:30:34.744912
8d0137b5-888b-4fbe-9f59-65198a716832	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:31:38.498692	2025-08-28 11:31:38.498692
5b07eb0f-7598-4a61-8c2d-684074c04f12	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:35:19.833692	2025-08-28 11:35:19.833692
a419e021-36ff-4f30-b5c3-067beeb83f05	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:35:24.668129	2025-08-28 11:35:24.668129
7990fd2e-3195-4794-a9d0-fd6fc22aee38	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:35:58.109609	2025-08-28 11:35:58.109609
9c72f8fc-bda5-4648-b746-17c47e2e0398	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:36:08.549901	2025-08-28 11:36:08.549901
9b4fec82-4ac2-4753-ba11-79b2424d4848	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:37:28.079287	2025-08-28 11:37:28.079287
6f34247d-305a-4961-8a61-6fc735199869	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": false}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:38:00.269898	2025-08-28 11:38:00.269898
6d1391ed-3c3f-4518-be61-75512187551b	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "active", "new_status": "disabled", "reason": "", "users_affected": true}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:45:29.666444	2025-08-28 11:45:29.666444
479c8e5b-4350-4897-a01b-e28732ba4406	3c8f5d18-2ba7-4424-ae5c-c22c106636fd	update_tenant_status	tenant	b7685340-0e7b-4f33-a31f-4f157b810648	{"tenant_name": "999", "old_status": "disabled", "new_status": "active", "reason": "", "users_affected": true}	192.168.4.143	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	\N	\N	2025-08-28 11:45:35.506937	2025-08-28 11:45:35.506937
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
0127c764fa7f
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, tenant_id, name, parent_id, icon, color, is_system, is_active, sort_order, description, created_at, updated_at) FROM stdin;
0716e06c-53c4-4442-a088-a46fb6a6b2cb	00000000-0000-0000-0000-000000000001	建筑材料	\N	\N	#FF6B6B	1	1	1	\N	2025-08-28 06:17:05.866945	2025-08-28 06:17:05.866945
e53a2a65-1ec8-4a2d-9b3b-f04c46edb0a6	00000000-0000-0000-0000-000000000001	人工费用	\N	\N	#4ECDC4	1	1	2	\N	2025-08-28 06:17:05.866945	2025-08-28 06:17:05.866945
3bbe3ac7-3637-49ff-8ecb-3d562ceeb423	00000000-0000-0000-0000-000000000001	设备租赁	\N	\N	#45B7D1	1	1	3	\N	2025-08-28 06:17:05.866945	2025-08-28 06:17:05.866945
9f1ce8b5-5286-46f2-afe3-ec941cc8cabe	00000000-0000-0000-0000-000000000001	项目管理	\N	\N	#96CEB4	1	1	4	\N	2025-08-28 06:17:05.866945	2025-08-28 06:17:05.866945
101eea66-f9f6-4a74-87fe-44e9f25c8faa	00000000-0000-0000-0000-000000000001	其他费用	\N	\N	#FFEAA7	1	1	5	\N	2025-08-28 06:17:05.866945	2025-08-28 06:17:05.866945
64142dd8-a7e2-4deb-85ab-901385101ffe	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	工程款收入	\N	💰	#52c41a	1	1	1	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
f21be628-3352-43cf-af0a-eedd67e1ff3d	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	材料退款	\N	📦	#1890ff	1	1	2	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
adc626b1-567c-4698-a649-157e4e440c5d	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	其他收入	\N	💸	#722ed1	1	1	3	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
875e65c1-8683-479f-996d-7c200855eb2f	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	材料费	\N	🧱	#fa541c	1	1	4	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
595cdab7-654d-4744-8116-f54d5d72817e	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	人工费	\N	👷	#eb2f96	1	1	5	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
ca252282-b3b7-4c0b-86b0-e7f43ca47cee	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	机械费	\N	🚛	#faad14	1	1	6	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
72b22df5-bc6c-4a82-b457-e48dd126e20c	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	管理费	\N	📋	#13c2c2	1	1	7	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
baf2738a-5fe6-4ec2-b003-847d1d225edf	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	差旅费	\N	✈️	#52c41a	1	1	8	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
c6e53005-4924-4177-893e-33e9343bc6ba	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	办公费	\N	🏢	#1890ff	1	1	9	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
45715721-4721-4513-9148-65b87b39ea61	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	其他支出	\N	💳	#722ed1	1	1	10	\N	2025-08-28 07:07:28.828487	2025-08-28 07:07:28.828487
\.


--
-- Data for Name: health_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_checks (id, service_name, status, response_time, error_details, check_details, service_version, last_success, failure_count, created_at, updated_at) FROM stdin;
9d1e304f-d2e9-4e55-ad3f-ae13a580f68d	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756365154.236066}}	\N	\N	0	2025-08-28 07:12:34.23467	2025-08-28 07:12:34.23467
e67e6b44-9fe0-4139-902f-0e150154de54	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756365217.3938046}}	\N	\N	0	2025-08-28 07:13:37.392443	2025-08-28 07:13:37.392443
a2562172-0ba1-432d-a7f6-77ef6abb7608	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756365218.6539786}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 3, "last_check": 1756365218.657176}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756365218.6582887}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756365218.6591704}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756365218.6600034}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756365218.6608372}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756365218.661798}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756365218.661799}]}	\N	\N	0	2025-08-28 07:13:38.595972	2025-08-28 07:13:38.595972
45169da9-bafe-414b-b513-66b73c346761	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756365232.0350688}}	\N	\N	0	2025-08-28 07:13:52.033736	2025-08-28 07:13:52.033736
73bdc5e7-d29d-4b99-9e53-1d578238e1bf	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756365297.6481237}}	\N	\N	0	2025-08-28 07:14:57.646968	2025-08-28 07:14:57.646968
e048b7e1-62d6-4f1c-9965-ddfa57bbbcce	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756365297.66762}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756365297.6694586}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756365297.6705425}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756365297.6715603}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756365297.6725223}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756365297.6733744}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756365297.6741896}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756365297.6741905}]}	\N	\N	0	2025-08-28 07:14:57.697437	2025-08-28 07:14:57.697437
631383e7-1581-4bae-b657-3d82444dff81	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756365301.0070817}}	\N	\N	0	2025-08-28 07:15:01.005938	2025-08-28 07:15:01.005938
7b884395-cfaa-479f-a109-c124806283bf	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756366503.8916051}}	\N	\N	0	2025-08-28 07:35:03.890372	2025-08-28 07:35:03.890372
473b76fc-084b-474b-b33f-1b714339d6c6	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366508.85788}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756366508.8595243}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366508.86042}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366508.8612552}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366508.8620436}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366508.8630276}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366508.863824}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366508.8638248}]}	\N	\N	0	2025-08-28 07:35:08.838206	2025-08-28 07:35:08.838206
45728244-6fcc-4a21-8c69-f1469315e9c7	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756366532.6314344}}	\N	\N	0	2025-08-28 07:35:32.630304	2025-08-28 07:35:32.630304
92a87974-4546-461e-9d1b-ed01efeee03d	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366532.652087}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756366532.6537108}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366532.6546633}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756366532.6558015}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366532.6566482}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366532.6574597}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366532.658248}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366532.658249}]}	\N	\N	0	2025-08-28 07:35:32.680726	2025-08-28 07:35:32.680726
78485a7e-337f-4449-9e32-a44619328dd2	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366546.10776}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756366546.1097007}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366546.1106176}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366546.1114478}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366546.1122644}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366546.113046}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366546.1138248}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366546.1138258}]}	\N	\N	0	2025-08-28 07:35:46.089343	2025-08-28 07:35:46.089343
f5dbb3b1-0cfc-4123-9999-16eae11f4dc9	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756366548.8108747}}	\N	\N	0	2025-08-28 07:35:48.809717	2025-08-28 07:35:48.809717
73db9a05-949f-43cd-be6c-8bd9a4f360e3	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366551.4762304}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756366551.478016}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366551.4789803}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366551.4798315}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756366551.4806738}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366551.4814723}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 0, "last_check": 1756366551.482438}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756366551.4824393}]}	\N	\N	0	2025-08-28 07:35:51.457911	2025-08-28 07:35:51.457911
f4166d3d-412c-4590-9c22-fb61c89b292a	system_overall	healthy	0	\N	{"database": {"status": "healthy", "response_time": 0, "last_check": 1756375259.086833}}	\N	\N	0	2025-08-28 10:00:59.085181	2025-08-28 10:00:59.085181
6af1e550-1011-4364-afd8-5c6363e6dcb5	api_endpoints	healthy	0	\N	{"endpoints": [{"endpoint": "\\u7528\\u6237\\u767b\\u5f55", "path": "/api/v1/auth/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756375260.0349247}, {"endpoint": "\\u9879\\u76ee\\u5217\\u8868", "path": "/api/v1/projects", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 2, "last_check": 1756375260.037407}, {"endpoint": "\\u8d22\\u52a1\\u8bb0\\u5f55\\u5217\\u8868", "path": "/api/v1/transactions", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756375260.038703}, {"endpoint": "\\u5206\\u7c7b\\u5217\\u8868", "path": "/api/v1/categories", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 1, "last_check": 1756375260.0398798}, {"endpoint": "\\u4f9b\\u5e94\\u5546\\u5217\\u8868", "path": "/api/v1/suppliers", "method": "GET", "status": "healthy", "status_code": 307, "response_time": 0, "last_check": 1756375260.0408163}, {"endpoint": "\\u79df\\u6237\\u7ba1\\u7406", "path": "/api/v1/admin/tenants", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 1, "last_check": 1756375260.0419023}, {"endpoint": "\\u7cfb\\u7edf\\u76d1\\u63a7", "path": "/api/v1/admin/health", "method": "GET", "status": "healthy", "status_code": 405, "response_time": 1, "last_check": 1756375260.0431907}, {"endpoint": "\\u76d1\\u63a7\\u7cfb\\u7edf\\u767b\\u5f55", "path": "/api/v1/monitoring/login", "method": "POST", "status": "requires_auth", "status_code": "N/A", "response_time": 0, "last_check": 1756375260.0431926}]}	\N	\N	0	2025-08-28 10:00:59.980873	2025-08-28 10:00:59.980873
\.


--
-- Data for Name: monitoring_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitoring_data (id, tenant_id, service_name, status, response_time, error_message, extra_data, alert_threshold, alert_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_change_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_change_logs (id, tenant_id, project_id, change_type, field_name, old_value, new_value, change_description, change_reason, changed_by, ip_address, user_agent, created_at, updated_at) FROM stdin;
ace3802c-9c21-4d5f-bdf6-a34b66c52362	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	8ee4d97d-ace4-4ee4-bcfc-e49f5cd0ce97	update	contract_amount,address	\N	\N	合同金额[9,999,999 元]变更成[99,999,999 元]，变更原因[合同变更]\n项目地址[8888]变更成[未填写]	合同变更	3afc2b42-456e-42ed-8e57-58a24ab3050c	\N	\N	2025-08-28 08:09:08.893179	2025-08-28 08:09:08.890631
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, tenant_id, name, project_code, description, project_type, category, tags, status, priority, progress, health_status, start_date, end_date, actual_start_date, actual_end_date, estimated_duration, actual_duration, budget, actual_cost, estimated_cost, cost_variance, budget_utilization, manager_name, manager_id, team_size, assigned_users, location, address, coordinates, client_info, contract_info, contract_number, contract_value, payment_terms, technical_specs, requirements, deliverables, quality_standards, risk_level, risk_factors, mitigation_plans, budget_change_reason, contract_change_reason, change_description, documents, attachments, approval_status, approval_history, workflow_stage, last_review_date, next_review_date, review_cycle, reporting_frequency, created_by, updated_by, is_active, is_template, created_at, updated_at) FROM stdin;
89acbdff-6e2a-47a8-916e-2f06b5f43411	00000000-0000-0000-0000-000000000001	示例工程项目	PRJ-001	这是一个示例工程项目，用于演示系统功能	construction	\N	[]	planning	medium	0	healthy	\N	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	\N	1	[]	{}	\N	\N	{}	{}	\N	\N	\N	\N	\N	\N	\N	low	\N	\N	\N	\N	\N	[]	[]	pending	\N	draft	\N	\N	\N	\N	00000000-0000-0000-0000-000000000001	\N	t	f	2025-08-28 06:17:05.870996	2025-08-28 06:17:05.870996
a161a91e-799a-4dc6-ba66-789901365614	18dbf77d-f5da-482e-97f3-4db0f7e45552	上海浦东办公楼	SHPD001	\N	construction	建筑工程	[]	active	high	0	healthy	2024-01-01	2024-12-31	\N	\N	\N	\N	\N	0.00	\N	\N	\N	张经理	\N	1	[]	{}	\N	\N	{}	{}	\N	\N	\N	\N	\N	\N	\N	low	\N	\N	\N	\N	\N	[]	[]	pending	\N	draft	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	t	f	2025-08-28 06:59:32.45845	2025-08-28 06:59:32.45845
9a5add49-98eb-4292-923b-ea25fa548750	18dbf77d-f5da-482e-97f3-4db0f7e45552	北京地铁站装修	BJDT001	\N	construction	装修工程	[]	active	medium	0	healthy	2024-02-01	2024-08-31	\N	\N	\N	\N	\N	0.00	\N	\N	\N	李经理	\N	1	[]	{}	\N	\N	{}	{}	\N	\N	\N	\N	\N	\N	\N	low	\N	\N	\N	\N	\N	[]	[]	pending	\N	draft	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	t	f	2025-08-28 06:59:32.460704	2025-08-28 06:59:32.460704
763ee73f-eca3-48f8-9c93-d49c9e48c1df	18dbf77d-f5da-482e-97f3-4db0f7e45552	广州设备安装	GZSBAZ001	\N	construction	设备安装	[]	active	low	0	healthy	2024-03-01	2024-06-30	\N	\N	\N	\N	\N	0.00	\N	\N	\N	王经理	\N	1	[]	{}	\N	\N	{}	{}	\N	\N	\N	\N	\N	\N	\N	low	\N	\N	\N	\N	\N	[]	[]	pending	\N	draft	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	t	f	2025-08-28 06:59:32.461843	2025-08-28 06:59:32.461843
3217944c-5303-4606-8dfd-54e879db70bd	18dbf77d-f5da-482e-97f3-4db0f7e45552	深圳市政道路	SZSZDL001	\N	construction	市政工程	[]	active	high	0	healthy	2024-04-01	2024-11-30	\N	\N	\N	\N	\N	0.00	\N	\N	\N	陈经理	\N	1	[]	{}	\N	\N	{}	{}	\N	\N	\N	\N	\N	\N	\N	low	\N	\N	\N	\N	\N	[]	[]	pending	\N	draft	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	t	f	2025-08-28 06:59:32.463143	2025-08-28 06:59:32.463143
8ee4d97d-ace4-4ee4-bcfc-e49f5cd0ce97	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	888	PRJ-20250828-140802-273-P8JBB7	8888888888888	municipal	\N	["重点项目"]	in_progress	medium	0	healthy	2025-08-28	2026-08-31	\N	\N	\N	\N	88888888.00	88787.00	\N	\N	\N	888	\N	1	[]	{}		\N	{"name": "888", "phone": "13388888888", "contact": "888"}	{}	\N	99999999.00	\N	\N	\N	\N	\N	low	\N	\N		合同变更	9999999	[]	[]	pending	\N	\N	\N	\N	\N	\N	3afc2b42-456e-42ed-8e57-58a24ab3050c	3afc2b42-456e-42ed-8e57-58a24ab3050c	t	f	2025-08-28 07:08:39.013016	2025-08-28 08:10:11.04734
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (id, tenant_id, name, code, contact_person, phone, email, address, business_scope, qualification, credit_rating, payment_terms, is_active, notes, tax_id, bank_account, rating, website, qualification_certificates, performance_history, created_at, updated_at) FROM stdin;
27a6ccd0-6965-4066-8117-b7bd0c539a88	00000000-0000-0000-0000-000000000001	示例供应商	SUP-001	张经理	13800138000	zhang@example.com	\N	\N	\N	\N	\N	1	\N	\N	\N	0	\N	[]	[]	2025-08-28 06:17:05.873619	2025-08-28 06:17:05.873619
c015e4c0-2406-44c8-a6ff-d5d2d93475bd	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	99999	\N	9999	19899999999	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	0	\N	[]	[]	2025-08-28 07:09:01.044315	2025-08-28 07:09:01.044315
\.


--
-- Data for Name: system_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_statistics (id, tenant_id, stat_date, stat_type, stat_data, alert_threshold, alert_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenant_activity (id, tenant_id, activity_date, login_count, project_operations, transaction_operations, supplier_operations, last_activity_at, activity_score, session_id, duration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, domain, plan_type, settings, subscription_end, storage_used, storage_limit, api_calls_used, api_calls_limit, status, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	默认租户	default	trial	{}	2025-09-27	0	5368709120	0	10000	active	2025-08-28 06:17:05.863998	2025-08-28 06:17:05.863998
18dbf77d-f5da-482e-97f3-4db0f7e45552	测试租户	test.local	basic	{}	\N	0	5368709120	0	1000	active	2025-08-28 06:57:11.074023	2025-08-28 06:57:11.074023
439096fb-e9c1-4137-b9a3-66d4f5158653	监控系统	monitoring.local	trial	{}	\N	0	5368709120	0	1000	active	2025-08-28 07:11:54.380666	2025-08-28 07:22:42.470963
b7685340-0e7b-4f33-a31f-4f157b810648	999	999	trial	{"company_size": "small", "industry_type": "contractor"}	\N	0	5368709120	0	1000	active	2025-08-28 09:58:09.018949	2025-08-28 11:45:35.478909
e6be2104-b6d6-4923-bb72-a0bea83a5fa9	888	888	trial	{"description": "专业的工程项目财务管理系统", "system_name": "888", "company_size": "medium", "industry_type": "contractor"}	\N	0	5368709120	0	1000	active	2025-08-28 07:07:12.026024	2025-08-28 11:07:11.553948
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, tenant_id, project_id, supplier_id, category_id, transaction_date, type, amount, currency, exchange_rate, description, notes, tags, payment_method, status, attachment_url, reference_number, approved_by, approved_at, created_by, invoice_number, due_date, attachments, tax_amount, discount_amount, created_at, updated_at) FROM stdin;
631b293e-61cd-4ce4-a4d3-8c53be13afa4	18dbf77d-f5da-482e-97f3-4db0f7e45552	a161a91e-799a-4dc6-ba66-789901365614	\N	\N	2025-08-28	income	1000000.00	CNY	1.000000	上海浦东办公楼合同款	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.820697	2025-08-28 07:00:07.820697
c2c8d260-4a71-4aac-b328-e98c095f5a00	18dbf77d-f5da-482e-97f3-4db0f7e45552	a161a91e-799a-4dc6-ba66-789901365614	\N	\N	2025-08-28	expense	300000.00	CNY	1.000000	上海浦东办公楼材料费	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.823039	2025-08-28 07:00:07.823039
7786f2df-8f15-403a-a9a5-bab3bc762d2a	18dbf77d-f5da-482e-97f3-4db0f7e45552	9a5add49-98eb-4292-923b-ea25fa548750	\N	\N	2025-08-28	income	1000000.00	CNY	1.000000	北京地铁站装修合同款	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.824499	2025-08-28 07:00:07.824499
819f9137-a33b-43b3-be8d-98c6b6e751be	18dbf77d-f5da-482e-97f3-4db0f7e45552	9a5add49-98eb-4292-923b-ea25fa548750	\N	\N	2025-08-28	expense	300000.00	CNY	1.000000	北京地铁站装修材料费	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.825512	2025-08-28 07:00:07.825512
2ae49385-523d-494d-a0f4-3b71f82891a7	18dbf77d-f5da-482e-97f3-4db0f7e45552	763ee73f-eca3-48f8-9c93-d49c9e48c1df	\N	\N	2025-08-28	income	1000000.00	CNY	1.000000	广州设备安装合同款	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.826565	2025-08-28 07:00:07.826565
d36c56fa-adf5-47a0-bfac-4b073035c44f	18dbf77d-f5da-482e-97f3-4db0f7e45552	763ee73f-eca3-48f8-9c93-d49c9e48c1df	\N	\N	2025-08-28	expense	300000.00	CNY	1.000000	广州设备安装材料费	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.827372	2025-08-28 07:00:07.827372
52cb31d7-5555-4a79-b848-727aef762251	18dbf77d-f5da-482e-97f3-4db0f7e45552	3217944c-5303-4606-8dfd-54e879db70bd	\N	\N	2025-08-28	income	1000000.00	CNY	1.000000	深圳市政道路合同款	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.828462	2025-08-28 07:00:07.828462
c8eda7d8-5c36-413f-9c71-74160d4f93e9	18dbf77d-f5da-482e-97f3-4db0f7e45552	3217944c-5303-4606-8dfd-54e879db70bd	\N	\N	2025-08-28	expense	300000.00	CNY	1.000000	深圳市政道路材料费	\N	\N	\N	confirmed	\N	\N	\N	\N	0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	\N	\N	[]	0.00	0.00	2025-08-28 07:00:07.830724	2025-08-28 07:00:07.830724
10ab240a-6e7e-4317-9a88-85b3042a7b70	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	8ee4d97d-ace4-4ee4-bcfc-e49f5cd0ce97	c015e4c0-2406-44c8-a6ff-d5d2d93475bd	45715721-4721-4513-9148-65b87b39ea61	2025-08-28	expense	88787.00	CNY	1.000000	8888888888		[]	wechat_pay	confirmed	\N	\N	\N	\N	3afc2b42-456e-42ed-8e57-58a24ab3050c	\N	\N	[]	0.00	0.00	2025-08-28 07:09:27.609278	2025-08-28 07:09:27.609281
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, tenant_id, username, email, password_hash, role, permissions, profile, last_login, login_count, is_active, email_verified, two_factor_enabled, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	00000000-0000-0000-0000-000000000001	admin	admin@example.com	$2b$12$YQ8K9mN2pL5vX7wR4tU6sA3bC1dE0fG2hI3jK4lM5nO6pQ7rS8tU9vW0xY1z	admin	["project_create", "project_read", "project_update", "project_delete", "transaction_create", "transaction_read", "transaction_update", "transaction_delete", "category_create", "category_read", "category_update", "category_delete", "supplier_create", "supplier_read", "supplier_update", "supplier_delete", "user_create", "user_read", "user_update", "user_delete", "tenant_read", "tenant_update", "report_read", "dashboard_read"]	{}	\N	0	t	f	f	2025-08-28 06:17:05.865123	2025-08-28 06:17:05.865123
30c10b02-899f-4281-af29-bc389a261a92	00000000-0000-0000-0000-000000000001	testuser	testuser@example.com	$2b$12$eCyiDsmMKRQyl3RfSQuXhO6nEyiCq.AeRlZVx8SO155bUjo0PbAG2	admin	["project_create", "project_read", "project_update", "project_delete", "transaction_create", "transaction_read", "transaction_update", "transaction_delete", "category_create", "category_read", "category_update", "category_delete", "supplier_create", "supplier_read", "supplier_update", "supplier_delete", "user_create", "user_read", "user_update", "user_delete", "tenant_read", "tenant_update", "report_read", "dashboard_read"]	{}	2025-08-28 07:48:23.881747	2	t	f	f	2025-08-28 06:56:16.613257	2025-08-28 07:48:23.642263
0cbe1b01-a0aa-456c-bec4-7457a31aa7a7	18dbf77d-f5da-482e-97f3-4db0f7e45552	user123	user123@example.com	$2b$12$HtmtdJ1yqqnpyvF3z5XuTOuxnvKONlFFYf8v7y0IjUnbeKDXNpYDW	admin	["project_create", "project_read", "project_update", "project_delete", "transaction_create", "transaction_read", "transaction_update", "transaction_delete", "category_read", "supplier_read", "report_read", "dashboard_read"]	{}	2025-08-28 08:04:46.00075	2	t	t	f	2025-08-28 06:57:11.337336	2025-08-28 08:04:45.761421
3afc2b42-456e-42ed-8e57-58a24ab3050c	e6be2104-b6d6-4923-bb72-a0bea83a5fa9	888	888@888.com	$2b$12$roirQi4rmTPoODDXhKRvquFOnQUAjYKbiB/gnBUgemXvtuBlXHzc2	super_admin	["*"]	{"name": "888", "phone": "18877774444"}	2025-08-28 10:07:43.903801	25	f	f	f	2025-08-28 07:07:12.026024	2025-08-28 11:07:06.598428
3c8f5d18-2ba7-4424-ae5c-c22c106636fd	439096fb-e9c1-4137-b9a3-66d4f5158653	admin	admin@monitoring.local	$2b$12$40CQJl.ey750MW8LUe7zVOj5g4r9yXallIOUFpSiM35tHdFKCll.a	super_admin	[]	{}	2025-08-28 11:37:12.601255	0	t	f	f	2025-08-28 07:11:54.380666	2025-08-28 11:37:12.387877
9df1686c-dc32-4777-8405-349524d81ff5	b7685340-0e7b-4f33-a31f-4f157b810648	999	999@999.com	$2b$12$sEGwuqRiB8B/EnlGF4XIUOmcApXiZnsVWTnQKO2.CO/jyG2mbs51y	super_admin	["*"]	{"name": "999", "phone": "18999999999"}	2025-08-29 08:06:44.477432	13	t	f	f	2025-08-28 09:58:09.018949	2025-08-29 08:06:44.220478
\.


--
-- Name: admin_operation_logs admin_operation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_operation_logs
    ADD CONSTRAINT admin_operation_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: health_checks health_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_checks
    ADD CONSTRAINT health_checks_pkey PRIMARY KEY (id);


--
-- Name: monitoring_data monitoring_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoring_data
    ADD CONSTRAINT monitoring_data_pkey PRIMARY KEY (id);


--
-- Name: project_change_logs project_change_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_change_logs
    ADD CONSTRAINT project_change_logs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_project_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_project_code_key UNIQUE (project_code);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_statistics system_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_statistics
    ADD CONSTRAINT system_statistics_pkey PRIMARY KEY (id);


--
-- Name: tenant_activity tenant_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_activity
    ADD CONSTRAINT tenant_activity_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_domain_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_domain_key UNIQUE (domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: idx_categories_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_categories_tenant_id ON public.categories USING btree (tenant_id);


--
-- Name: idx_projects_created_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_created_by ON public.projects USING btree (created_by);


--
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- Name: idx_projects_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_tenant_id ON public.projects USING btree (tenant_id);


--
-- Name: idx_suppliers_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suppliers_tenant_id ON public.suppliers USING btree (tenant_id);


--
-- Name: idx_transactions_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_date ON public.transactions USING btree (transaction_date);


--
-- Name: idx_transactions_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_project_id ON public.transactions USING btree (project_id);


--
-- Name: idx_transactions_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_tenant_id ON public.transactions USING btree (tenant_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: admin_operation_logs admin_operation_logs_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_operation_logs
    ADD CONSTRAINT admin_operation_logs_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.users(id);


--
-- Name: admin_operation_logs admin_operation_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_operation_logs
    ADD CONSTRAINT admin_operation_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: categories categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: monitoring_data monitoring_data_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoring_data
    ADD CONSTRAINT monitoring_data_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: project_change_logs project_change_logs_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_change_logs
    ADD CONSTRAINT project_change_logs_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: project_change_logs project_change_logs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_change_logs
    ADD CONSTRAINT project_change_logs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_change_logs project_change_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_change_logs
    ADD CONSTRAINT project_change_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: projects projects_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: projects projects_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.users(id);


--
-- Name: projects projects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: projects projects_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: suppliers suppliers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: system_statistics system_statistics_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_statistics
    ADD CONSTRAINT system_statistics_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: tenant_activity tenant_activity_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_activity
    ADD CONSTRAINT tenant_activity_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: transactions transactions_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: transactions transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO ledger_user;


--
-- Name: TABLE admin_operation_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.admin_operation_logs TO ledger_user;


--
-- Name: TABLE alembic_version; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.alembic_version TO ledger_user;


--
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.categories TO ledger_user;


--
-- Name: TABLE health_checks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.health_checks TO ledger_user;


--
-- Name: TABLE monitoring_data; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.monitoring_data TO ledger_user;


--
-- Name: TABLE project_change_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.project_change_logs TO ledger_user;


--
-- Name: TABLE projects; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.projects TO ledger_user;


--
-- Name: TABLE suppliers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.suppliers TO ledger_user;


--
-- Name: TABLE system_statistics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_statistics TO ledger_user;


--
-- Name: TABLE tenant_activity; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tenant_activity TO ledger_user;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tenants TO ledger_user;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.transactions TO ledger_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO ledger_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: ledger_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE ledger_user IN SCHEMA public GRANT ALL ON TABLES TO ledger_user;


--
-- PostgreSQL database dump complete
--

